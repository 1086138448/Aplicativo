import subprocess
import os
import shutil
import tkinter as tk
from tkinter import font, messagebox

# Ruta a la carpeta donde están los archivos (instaladores y archivos a copiar)
carpeta_origen = r"AppInstalar/Assent/Applis"  # Cambia esta ruta a la ubicación de tu carpeta con los archivos

# Ruta al escritorio del usuario
escritorio = os.path.join(os.path.expanduser("~"), "Desktop")

# Lista de archivos que deseas copiar al escritorio
archivos_para_copiar = [
    "documento1.txt",  # Reemplaza con el nombre de tu primer archivo
    "configuracion.xml",  # Reemplaza con el nombre de tu segundo archivo
]

# Lista de los instaladores que deseas ejecutar
archivos_instaladores = [
    "aplicacion1.exe",  # Reemplaza con el nombre de tu primer archivo de instalación
    "aplicacion2.msi",  # Reemplaza con el nombre de tu segundo archivo de instalación
    "aplicacion3.exe",  # Reemplaza con el nombre de tu tercer archivo de instalación
]

# Ruta a la carpeta donde están las fuentes
ruta_fuentes = r"C:\AppInstalar\Assent\Fonts"  # Ruta a la carpeta de tus fuentes personalizadas
fuente_personalizada = "nombre_de_tu_fuente.ttf"  # Cambia esto por el nombre real de tu fuente

# Función para instalar las aplicaciones
def instalar_aplicaciones():
    for archivo in archivos_instaladores:
        ruta_archivo = os.path.join(carpeta_origen, archivo)
        print(f"Instalando {archivo}...")
        
        try:
            # Verificar si el archivo es .exe o .msi y proceder con la instalación correspondiente
            if archivo.endswith('.exe'):
                subprocess.run([ruta_archivo, "/quiet", "/norestart"], check=True)  # Para .exe
            elif archivo.endswith('.msi'):
                subprocess.run(["msiexec", "/i", ruta_archivo, "/quiet", "/norestart"], check=True)  # Para .msi
            
            print(f"{archivo} instalado correctamente.")
        except subprocess.CalledProcessError as e:
            print(f"Hubo un error al instalar {archivo}: {e}")
            messagebox.showerror("Error", f"Hubo un error al instalar {archivo}: {e}")

# Función para copiar los archivos al escritorio
def copiar_archivos_al_escritorio():
    for archivo in archivos_para_copiar:
        ruta_origen = os.path.join(carpeta_origen, archivo)
        destino = os.path.join(escritorio, archivo)
        
        try:
            # Verificar si el archivo existe y copiarlo al escritorio
            if os.path.exists(ruta_origen):
                shutil.copy(ruta_origen, destino)
                print(f"Archivo {archivo} copiado al escritorio.")
            else:
                print(f"El archivo {archivo} no se encuentra en la carpeta especificada.")
                messagebox.showwarning("Advertencia", f"El archivo {archivo} no se encuentra en la carpeta especificada.")
        except Exception as e:
            print(f"Hubo un error al copiar el archivo {archivo}: {e}")
            messagebox.showerror("Error", f"Hubo un error al copiar el archivo {archivo}: {e}")

# Función para actualizar la interfaz mientras se realizan las tareas
def ejecutar_tareas():
    # Deshabilitar los botones para evitar múltiples clics
    boton_instalar.config(state=tk.DISABLED)
    boton_copiar.config(state=tk.DISABLED)
    
    # Llamamos a las funciones para realizar las tareas
    instalar_aplicaciones()
    copiar_archivos_al_escritorio()
    
    # Habilitar los botones después de terminar
    boton_instalar.config(state=tk.NORMAL)
    boton_copiar.config(state=tk.NORMAL)

# Crear la ventana principal
root = tk.Tk()
root.title("Instalador con Logo")

# Configuración de la ventana (fondo blanco)
root.configure(bg="white")

# Cargar la fuente personalizada si está disponible
if os.path.exists(os.path.join(ruta_fuentes, fuente_personalizada)):
    fuente = font.Font(family=fuente_personalizada, size=14)
else:
    fuente = font.Font(family="Helvetica", size=14)  # Fuente predeterminada si no se carga la personalizada

# Crear una etiqueta de bienvenida
etiqueta_bienvenida = tk.Label(root, text="Bienvenido al instalador", font=fuente, fg="green", bg="white")
etiqueta_bienvenida.pack(pady=20)

# Botón para iniciar la instalación
boton_instalar = tk.Button(root, text="Instalar Aplicaciones", command=ejecutar_tareas, font=fuente, fg="white", bg="green")
boton_instalar.pack(pady=10)

# Botón para copiar archivos al escritorio
boton_copiar = tk.Button(root, text="Copiar Archivos al Escritorio", command=ejecutar_tareas, font=fuente, fg="white", bg="green")
boton_copiar.pack(pady=10)

# Mostrar la ventana
root.mainloop()
